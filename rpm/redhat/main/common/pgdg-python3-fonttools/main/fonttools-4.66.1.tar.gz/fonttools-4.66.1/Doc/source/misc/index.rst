##########################################################
misc: Miscellaneous libraries helpful for font engineering
##########################################################

.. currentmodule:: fontTools.misc

.. rubric:: Overview:
   :heading-level: 2

:mod:`fontTools.misc` is a collection of modules, most of which are
used as internal support utilities by fontTools, but some of which may
be more generally useful.

.. toctree::
   :maxdepth: 1

   arrayTools
   bezierTools
   classifyTools
   cliTools
   configTools
   eexec
   encodingTools
   etree
   filenames
   fixedTools
   intTools
   loggingTools
   macCreatorType
   macRes
   plistlib
   psCharStrings
   psLib
   psOperators
   roundTools
   sstruct
   symfont
   testTools
   textTools
   timeTools
   transform
   visitor
   xmlReader
   xmlWriter

/******************************************************************************
 * Project:  OGR
 * Purpose:  OGRGMLASDriver implementation
 * Author:   Even Rouault, <even dot rouault at spatialys dot com>
 *
 * Initial development funded by the European Earth observation programme
 * Copernicus
 *
 ******************************************************************************
 * Copyright (c) 2016, Even Rouault, <even dot rouault at spatialys dot com>
 *
 * SPDX-License-Identifier: MIT
 ****************************************************************************/

#include "gdal_frmts.h"
#include "gdalplugindriverproxy.h"

#include "ogrsf_frmts.h"

#include "ogrgmlasdrivercore.h"
#include "ogr_gmlas_consts.h"

/************************************************************************/
/*                    OGRGMLASDriverIdentify()                          */
/************************************************************************/

int OGRGMLASDriverIdentify(GDALOpenInfo *poOpenInfo)

{
    if (STARTS_WITH_CI(poOpenInfo->pszFilename, "GMLAS:"))
        return true;

    if (poOpenInfo->IsSingleAllowedDriver("GMLAS"))
    {
        const char *pszPtr =
            reinterpret_cast<const char *>(poOpenInfo->pabyHeader);

        // Skip UTF-8 BOM
        if (poOpenInfo->nHeaderBytes > 3 &&
            memcmp(poOpenInfo->pabyHeader, "\xEF\xBB\xBF", 3) == 0)
        {
            pszPtr += 3;
        }

        // Skip spaces
        while (*pszPtr && std::isspace(static_cast<unsigned char>(*pszPtr)))
            ++pszPtr;

        // Here, we expect the opening chevrons of GML tree root element */
        return pszPtr[0] == '<';
    }

    return false;
}

/************************************************************************/
/*                  OGRGMLASDriverSetCommonMetadata()                   */
/************************************************************************/

void OGRGMLASDriverSetCommonMetadata(GDALDriver *poDriver)
{
    poDriver->SetDescription(DRIVER_NAME);
    poDriver->SetMetadataItem(GDAL_DCAP_VECTOR, "YES");
    poDriver->SetMetadataItem(GDAL_DMD_LONGNAME,
                              "Geography Markup Language (GML) "
                              "driven by application schemas");
    poDriver->SetMetadataItem(GDAL_DMD_EXTENSIONS, "gml xml");
    poDriver->SetMetadataItem(GDAL_DMD_HELPTOPIC, "drivers/vector/gmlas.html");

    poDriver->SetMetadataItem(GDAL_DMD_CONNECTION_PREFIX, szGMLAS_PREFIX);
    poDriver->SetMetadataItem(GDAL_DMD_SUPPORTED_SQL_DIALECTS, "OGRSQL SQLITE");

    poDriver->SetMetadataItem(
        GDAL_DMD_OPENOPTIONLIST,
        "<OpenOptionList>"
        "  <Option name='XSD' type='string' description='Space separated list "
        "of "
        "filenames of XML schemas that apply to the data file'/>"
        "  <Option name='CONFIG_FILE' type='string' "
        "description='Filename of the configuration file'/>"
        "  <Option name='EXPOSE_METADATA_LAYERS' type='boolean' "
        "description='Whether metadata layers should be reported by default.' "
        "default='NO'/>"
        "  <Option name='SCHEMA_FULL_CHECKING' type='boolean' description="
        "'Whether the full schema constraint checking should be enabled.' "
        "default='YES'/>"
        "  <Option name='HANDLE_MULTIPLE_IMPORTS' type='boolean' "
        "description='Whether "
        "multiple imports of the same namespace can be done.' default='NO'/>"
        "  <Option name='VALIDATE' type='boolean' description='Whether "
        "validation "
        "against the schema should be done' default='NO'/>"
        "  <Option name='FAIL_IF_VALIDATION_ERROR' type='boolean' "
        "description='Whether a validation error should cause dataset opening "
        "to fail' "
        "default='NO'/>"
        "  <Option name='REFRESH_CACHE' type='boolean' "
        "description='Whether remote schemas and resolved xlink resources "
        "should "
        "be downloaded from the server' "
        "default='NO'/>"
        "  <Option name='SWAP_COORDINATES' type='string-select' "
        "description='Whether the order of geometry coordinates should be "
        "inverted.' "
        "default='AUTO'>"
        "    <Value>AUTO</Value>"
        "    <Value>YES</Value>"
        "    <Value>NO</Value>"
        "  </Option>"
        "  <Option name='REMOVE_UNUSED_LAYERS' type='boolean' "
        "description='Whether unused layers should be removed' "
        "default='NO'/>"
        "  <Option name='REMOVE_UNUSED_FIELDS' type='boolean' "
        "description='Whether unused fields should be removed' "
        "default='NO'/>"
        "</OpenOptionList>");

    poDriver->SetMetadataItem(
        GDAL_DMD_CREATIONOPTIONLIST,
        (CPLString("<CreationOptionList>") + "  <Option name='" +
         szINPUT_XSD_OPTION +
         "' type='string' description='"
         "Space separated list of filenames of XML schemas that apply to the "
         "data file'/>"
         "  <Option name='" +
         szCONFIG_FILE_OPTION +
         "' type='string' "
         "description='Filename of the configuration file'/>"
         "  <Option name='" +
         szLAYERS_OPTION +
         "' type='string' "
         "description='Comma separated list of layer names to export'/>"
         "  <Option name='" +
         szSRSNAME_FORMAT_OPTION +
         "' type='string-select' "
         "description='Format of srsName' "
         "default='" +
         szSRSNAME_DEFAULT +
         "'>"
         "    <Value>" +
         szSHORT +
         "</Value>"
         "    <Value>" +
         szOGC_URN +
         "</Value>"
         "    <Value>" +
         szOGC_URL +
         "</Value>"
         "  </Option>"
         "  <Option name='" +
         szINDENT_SIZE_OPTION +
         "' type='int' min='0' max='8' "
         "description='Number of spaces for each indentation level' "
         "default='2'/>"
         "  <Option name='" +
         szCOMMENT_OPTION +
         "' type='string' description='"
         "Comment to add at top of generated XML file'/>"
         "  <Option name='" +
         szLINEFORMAT_OPTION +
         "' type='string-select' "
         "description='end-of-line sequence' "
#ifdef _WIN32
         "default='" +
         szCRLF +
         "'>"
#else
         "default='" +
         szLF +
         "'>"
#endif
         "    <Value>" +
         szCRLF +
         "</Value>"
         "    <Value>" +
         szLF +
         "</Value>"
         "  </Option>"
         "  <Option name='" +
         szWRAPPING_OPTION +
         "' type='string-select' "
         "description='How to wrap features' "
         "default='" +
         szWFS2_FEATURECOLLECTION +
         "'>"
         "    <Value>" +
         szWFS2_FEATURECOLLECTION +
         "</Value>"
         "    <Value>" +
         szGMLAS_FEATURECOLLECTION +
         "</Value>"
         "  </Option>"
         "  <Option name='" +
         szTIMESTAMP_OPTION +
         "' type='string' "
         "description='User-specified XML "
         "dateTime value for timestamp to use in wfs:FeatureCollection "
         "attribute."
         "Only valid for " +
         szWRAPPING_OPTION + "=" + szWFS2_FEATURECOLLECTION +
         "'/>"
         "  <Option name='" +
         szWFS20_SCHEMALOCATION_OPTION +
         "' type='string' "
         "description='Path or URL to wfs.xsd. Only valid for " +
         szWRAPPING_OPTION + "=" + szWFS2_FEATURECOLLECTION +
         "'/>"
         "  <Option name='" +
         szGENERATE_XSD_OPTION +
         "' type='boolean' "
         "description='Whether to generate a .xsd file. Only valid for " +
         szWRAPPING_OPTION + "=" + szGMLAS_FEATURECOLLECTION +
         "' "
         "default='YES'/>"
         "  <Option name='" +
         szOUTPUT_XSD_FILENAME_OPTION +
         "' type='string' "
         "description='Wrapping .xsd filename. If not specified, same "
         "basename as output file with .xsd extension. Only valid for " +
         szWRAPPING_OPTION + "=" + szGMLAS_FEATURECOLLECTION +
         "'/>"
         "</CreationOptionList>")
            .c_str());

    poDriver->SetMetadataItem(GDAL_DCAP_VIRTUALIO, "YES");
    poDriver->SetMetadataItem(GDAL_DCAP_MULTIPLE_VECTOR_LAYERS, "YES");

    poDriver->pfnIdentify = OGRGMLASDriverIdentify;
    poDriver->SetMetadataItem(GDAL_DCAP_OPEN, "YES");
    poDriver->SetMetadataItem(GDAL_DCAP_CREATECOPY, "YES");
}

/************************************************************************/
/*                   DeclareDeferredOGRGMLASPlugin()                    */
/************************************************************************/

#ifdef PLUGIN_FILENAME
void DeclareDeferredOGRGMLASPlugin()
{
    if (GDALGetDriverByName(DRIVER_NAME) != nullptr)
    {
        return;
    }
    auto poDriver = new GDALPluginDriverProxy(PLUGIN_FILENAME);
#ifdef PLUGIN_INSTALLATION_MESSAGE
    poDriver->SetMetadataItem(GDAL_DMD_PLUGIN_INSTALLATION_MESSAGE,
                              PLUGIN_INSTALLATION_MESSAGE);
#endif
    OGRGMLASDriverSetCommonMetadata(poDriver);
    GetGDALDriverManager()->DeclareDeferredPluginDriver(poDriver);
}
#endif

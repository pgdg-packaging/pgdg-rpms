%extend GDALDatasetShadow {

}
